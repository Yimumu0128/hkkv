# ForgematicaPrinter Plus（1.20.1 / Forge 二次开发源码补丁）

这是**真源码补丁**，不是成品 jar。目标基线是 TexTrue / ThinkingStudios 的
`ForgematicaPrinter-0.1.0+mc1.20.1`（Forge 47.3.5，Architectury Loom + Yarn 1.20.1+build.10）。

代码对齐了从官方仓库 `forge/1.20.1` 分支拉到的真实基线源码：包名、Yarn 映射名、
`ConfigsMixin` 把配置追加到 `M+C -> 通用(Generic)` 页底部的 Redirect 方式、
`PlayerMoveC2SPacket.Full` 静默转头、`interactionManager.interactBlock` 发包方式，全部与基线一致。

---

## 1. 怎么用这份补丁

```bash
git clone -b forge/1.20.1 https://github.com/ThinkingStudios/ForgematicaPrinter.git
# 把本目录里的 src/ 覆盖进仓库根目录：
#   - 4 个「替换」文件：直接覆盖同名文件
#   - plus/ 包 + handler/ 子包：全部新增
#   - assets/litematica-printer/lang/zh_cn.json：新增（如已有同名文件请合并键，不要覆盖）
JDK 17 环境下：
./gradlew build
# 产物：build/libs/ForgematicaPrinter-0.1.0+mc1.20.1.jar
```

依赖版本（与基线 `gradle.properties` 一致，不需要改 build.gradle.kts）：

| 项 | 版本 |
|---|---|
| Minecraft | 1.20.1 |
| Forge | 1.20.1-47.3.5 |
| Yarn | 1.20.1+build.10 |
| MaFgLib | 0.1.13-mc1.20.1 |
| Forgematica | 0.1.12-mc1.20.1 |

`META-INF/mods.toml`、两个 `*.mixins.json` **不需要改**：本补丁没有新增 Mixin，
新逻辑走 Forge 的 `TickEvent.ClientTickEvent` 事件总线（`PrinterPlus.register()` 在
`ForgematicaPrinter` 构造器里注册）。

---

## 2. 文件清单

**替换（4 个）**

| 文件 | 改动 |
|---|---|
| `config/Configs.java` | 保留基线 7 项，新增 ~40 项配置，全部追加进 `getConfigList()` |
| `config/Hotkeys.java` | 新增 6 个模式热键 + 紧急停止热键 |
| `event/KeyCallbacks.java` | 把新热键绑定到对应 `ConfigBoolean` |
| `org/thinkingstudio/.../ForgematicaPrinter.java` | 构造器里调用 `PrinterPlus.register()` |

**新增（`me/aleksilassila/litematica/printer/plus/`）**

| 文件 | 作用 |
|---|---|
| `PrinterPlus.java` | Forge 客户端 tick 调度、节流、紧急停止 |
| `WorkContext.java` | 世界/投影/队列/处理器集合 |
| `WorkHandler.java` | 处理器接口 |
| `WorkQueue.java` | **串行确认队列**：发包 → 等服务端方块更新 → 再推进；超时重试 |
| `CoordinateScanner.java` | 跨 tick 坐标游标、扫描预算、选区/半径回退 |
| `SelectionProvider.java` | 反射读取 Forgematica 选区包围盒（适配不同移植分支的方法名） |
| `PlacementHelper.java` | 找合法点击面 / 虚拟支撑面 |
| `InventoryBridge.java` | 切物品、解析方块 ID、黑白名单 |
| `StateMatcher.java` | 宽松状态比对、含水/冰/流体源判定 |
| `CoralMapper.java` | 死珊瑚 → 活珊瑚（`dead_` 前缀去掉即可） |
| `Chats.java` | 游戏内提示 |
| `handler/FillHandler.java` | 选区填充 |
| `handler/FluidHandler.java` | 流体排空 |
| `handler/MineHandler.java` | 挖掘模式 |
| `handler/BedrockHandler.java` | 破基岩（配套 mod 转发） |
| `handler/SpecialBlocksHandler.java` | 含水 / 珊瑚 / 破冰纠错 |
| `handler/AirPlacementHandler.java` | 凭空放置 |

---

## 3. 功能 → 代码 → 配置项

| 需求 | 代码位置 | 配置键 | 状态 |
|---|---|---|---|
| 选区填充指定方块 | `FillHandler` | `enableFill / fillBlock / fillHandHeld / fillReplaceMode / fillUseSelection` | ✅ 已写 |
| 流体排空（水/岩浆源） | `FluidHandler` | `enableFluidDrain / drainWater / drainLava / drainFlowing / drainMethod / drainCoverBlock / drainRemoveCover` | ✅ 已写（见限制 4.1） |
| 挖掘模式（一键挖选区） | `MineHandler` | `enableMine / mineFilter / mineCheckHardness / mineAutoTool / mineWhitelist / mineBlacklist` | ✅ 已写 |
| 破基岩模式（需配套 mod） | `BedrockHandler` | `enableBedrock / bedrockModId / bedrockAllowlist / bedrockApiClass` | ✅ 已写（转发式，见 4.2） |
| 含水方块兼容 | `SpecialBlocksHandler` | `handleWaterlogged` | ✅ 已写（vanilla「先放水再放方块」两步法） |
| 珊瑚替换（死→活） | `CoralMapper` + `SpecialBlocksHandler` | `replaceDeadCoral` | ✅ 已写 |
| 冰处理自动纠错（高危） | `SpecialBlocksHandler` | `iceCorrection` + `destructiveMode` | ✅ 已写（破冰→放水顺序队列） |
| 凭空放置 printInAir | `AirPlacementHandler` | `printInAir / printInAirMode / printInAirUseSelection` | ✅ 已写（实验性，见 4.3） |
| 配置界面可设置 | `Configs.getConfigList()` 经 `ConfigsMixin` 注入 | 全部键 | ✅ 已写，出现在 M+C → 通用页底部 |
| 热键 / 紧急停止 | `Hotkeys` + `KeyCallbacks` + `PrinterPlus.emergencyStop()` | Hotkeys 页 | ✅ 已写 |
| 破坏性总闸 + 二次保护 | `destructiveMode` 控制 Mine/Bedrock/Ice | — | ✅ 已写 |

**没有写进这版源码的（别误以为有）**：48 种迭代顺序、进度条 HUD、缺失材料 HUD、
QuickShulker / ChestTracker 取物、双挖并行、数据包直发打印（本版走 `interactionManager`
交互）、服务端 companion、破基岩的活塞机械实现、告示牌/头颅等复杂方块状态。

---

## 4. 必须知道的运行时限制

**4.1 流体排空不是真的 `setBlock`**
纯客户端没有改世界的权限。`BUCKET` 模式靠空桶右键流体源（背包必须有空桶），
`COVER` 模式靠放实心方块挤掉源再挖掉。服务端可能拒绝，队列会超时重试后跳过并记日志。

**4.2 破基岩只是「转发」**
Forge 1.20.1 没有 Fabric-Bedrock-Miner 对应物。本代码检测 `bedrockModId` 是否加载，
把基岩坐标交给配套 mod（可配 `bedrockApiClass` 的静态 `breakBlock(BlockPos)`），
没配就退化成 `attackBlock`。Tweakerge 的 Breaking Grid ≠ 破基岩，别填错 modId。

**4.3 凭空放置是实验性**
原版交互包需要合法点击面；无支撑时本代码用虚拟命中发包，服务端大概率拒绝。
`TWEAKERGE` 模式只做「检测到 Tweakerge 才启用」，没有直接调用它的内部 API。
真要稳定浮空放置，建议在创造模式配合 Tweakerge 的灵活放置，或改成服务端 companion。

**4.4 两套打印别同时开**
基线 `PlayerMoveC2SPacketMixin` 会在 `lookAction != null` 时改写所有视角包的 yaw/pitch。
跑新模式时建议关掉 `printingMode`，否则可能互相抢坐标 / 朝向。

**4.5 服务器合规**
静默视角 + 高频发包容易被反作弊判违规；放置速率限制（Luminol 等）会放错方块。
调大 `workInterval` / `printingInterval`。破坏性模式先备份存档。

---

## 5. 编译前可能需要微调的地方

我没有在本地跑 ForgeGradle 完整编译（沙盒拿不到 MC/Forge 依赖），但已按官方
`forge/1.20.1` 源码逐行对齐 API，并逐项核对了 Yarn `1.20.1+build.10` 的 javadoc：
`attackBlock(BlockPos,Direction)`、`updateBlockBreakingProgress(BlockPos,Direction)`、
`interactBlock(ClientPlayerEntity,Hand,BlockHitResult)`、`clickCreativeStack(ItemStack,int)`、
`FluidState.isStill()/isEmpty()`、`MinecraftClient.inGameHud.getChatHud()`、
`AbstractBlock.getHardness()` 均确认存在。剩下两处按你的环境决定：

1. **`ConfigString`**：本版用了 `fi.dy.masa.malilib.config.options.ConfigString`
   （构造 `(name, default, comment)`，读 `getStringValue()`；MaLiLib 的 STRING 配置类型）。
   若你那版 MaFgLib 类名不同，把 `Configs.java` 里 8 个字符串配置换成 `ConfigStringList`
   或改成 `ConfigInteger` 枚举码即可。
2. **`SelectionProvider`** 是反射适配（Forgematica 各移植分支的
   `DataManager` / `AreaSelection` / `Box` 方法名不完全一致）；确认 0.1.12 的确切签名后，
   可换成直接调用提速。反射失败时会自动回退到「玩家周围打印半径」范围，不会崩游戏。

另外：`zh_cn.json` 里同时写了 `litematica-printer.config.name.*` 和 `malilib.config.name.*`
两套键，因为不同 MaFgLib 版本取翻译键的前缀不同；配置项的中文说明本身已经写在
`comment` 字符串里，即使语言文件没生效，鼠标悬停也能看到中文。

---

## 6. 许可

基线 `ForgematicaPrinter` 与上游 `Litematica Printer` 均为 **AGPL-3.0-only**。
本补丁是衍生作品，分发编译产物时必须同许可、保留版权声明、并提供对应源码。
不要只发 jar 不发源码。
