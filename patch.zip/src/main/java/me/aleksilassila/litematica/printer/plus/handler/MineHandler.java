package me.aleksilassila.litematica.printer.plus.handler;

import me.aleksilassila.litematica.printer.config.Configs;
import me.aleksilassila.litematica.printer.plus.CoordinateScanner;
import me.aleksilassila.litematica.printer.plus.InventoryBridge;
import me.aleksilassila.litematica.printer.plus.StateMatcher;
import me.aleksilassila.litematica.printer.plus.WorkContext;
import me.aleksilassila.litematica.printer.plus.WorkHandler;
import me.aleksilassila.litematica.printer.plus.WorkQueue;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ToolItem;
import net.minecraft.util.math.BlockPos;

import java.util.List;
import java.util.Set;

/** 挖掘模式：按选区/范围一键挖掉方块。受 destructiveMode 总闸控制。 */
public final class MineHandler implements WorkHandler {
    private final CoordinateScanner scanner = new CoordinateScanner();

    @Override
    public String name() { return "Mine"; }

    @Override
    public boolean isEnabled() {
        return Configs.ENABLE_MINE.getBooleanValue() && Configs.DESTRUCTIVE_MODE.getBooleanValue();
    }

    @Override
    public boolean tick(WorkContext ctx) {
        List<BlockPos> coords = scanner.next(ctx, Configs.MINE_USE_SELECTION.getBooleanValue(),
                Math.max(1, Configs.SCAN_BUDGET.getIntegerValue()));
        String filter = Configs.MINE_FILTER.getStringValue();
        Set<String> whitelist = InventoryBridge.parseIdList(Configs.MINE_WHITELIST.getStringValue());
        Set<String> blacklist = InventoryBridge.parseIdList(Configs.MINE_BLACKLIST.getStringValue());
        boolean loose = Configs.MATCH_SAME_ITEM.getBooleanValue();

        for (BlockPos pos : coords) {
            if (!ctx.inReach(pos)) continue;
            BlockState cur = ctx.world.getBlockState(pos);
            if (cur.isAir()) continue;

            String id = InventoryBridge.blockId(cur.getBlock());
            if (!whitelist.isEmpty() && !whitelist.contains(id)) continue;
            if (blacklist.contains(id)) continue;
            if (cur.getBlock() == Blocks.BARRIER || cur.getBlock() == Blocks.STRUCTURE_VOID) continue;
            if (Configs.MINE_CHECK_HARDNESS.getBooleanValue() && cur.getBlock().getHardness() < 0) continue;

            BlockState target = ctx.schematic == null ? null : ctx.schematic.getBlockState(pos);
            boolean doMine;
            if ("EXTRA_ONLY".equalsIgnoreCase(filter)) {
                doMine = target != null && target.isAir();
            } else if ("WRONG_STATE_ONLY".equalsIgnoreCase(filter)) {
                doMine = target != null && !target.isAir() && !StateMatcher.matches(target, cur, loose);
            } else {
                doMine = true;
            }
            if (!doMine) continue;

            if (Configs.MINE_AUTO_TOOL.getBooleanValue()) selectTool(ctx, cur);
            ctx.queue.submit(WorkQueue.Task.brk(pos, WorkQueue.Type.BREAK));
            return true;
        }
        return false;
    }

    private static void selectTool(WorkContext ctx, BlockState state) {
        PlayerInventory inv = ctx.player.getInventory();
        for (int i = 0; i < 9; i++) {
            ItemStack stack = inv.getStack(i);
            if (!stack.isEmpty() && stack.getItem() instanceof ToolItem) {
                inv.selectedSlot = i;
                return;
            }
        }
    }
}
