package me.aleksilassila.litematica.printer.plus.handler;

import me.aleksilassila.litematica.printer.config.Configs;
import me.aleksilassila.litematica.printer.plus.Chats;
import me.aleksilassila.litematica.printer.plus.CoordinateScanner;
import me.aleksilassila.litematica.printer.plus.InventoryBridge;
import me.aleksilassila.litematica.printer.plus.PlacementHelper;
import me.aleksilassila.litematica.printer.plus.StateMatcher;
import me.aleksilassila.litematica.printer.plus.WorkContext;
import me.aleksilassila.litematica.printer.plus.WorkHandler;
import me.aleksilassila.litematica.printer.plus.WorkQueue;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.util.math.BlockPos;

import java.util.List;

/** 排流体：空桶装走水/岩浆源，或放实心方块挤掉流体源。 */
public final class FluidHandler implements WorkHandler {
    private final CoordinateScanner scanner = new CoordinateScanner();
    private boolean warnedMissingItem;

    @Override
    public String name() { return "Fluid"; }

    @Override
    public boolean isEnabled() { return Configs.ENABLE_FLUID_DRAIN.getBooleanValue(); }

    @Override
    public boolean tick(WorkContext ctx) {
        List<BlockPos> coords = scanner.next(ctx, Configs.FLUID_USE_SELECTION.getBooleanValue(),
                Math.max(1, Configs.SCAN_BUDGET.getIntegerValue()));
        boolean cover = "COVER".equalsIgnoreCase(Configs.DRAIN_METHOD.getStringValue());

        Item coverItem = cover ? InventoryBridge.parseItem(Configs.DRAIN_COVER_BLOCK.getStringValue()) : null;
        if (cover && (coverItem == null || coverItem == Items.AIR)) {
            if (!warnedMissingItem) {
                Chats.say(ctx, "覆盖方块 ID 无法解析，请检查 drainCoverBlock 配置");
                warnedMissingItem = true;
            }
            return false;
        }
        warnedMissingItem = false;

        for (BlockPos pos : coords) {
            if (!ctx.inReach(pos)) continue;
            BlockState cur = ctx.world.getBlockState(pos);
            boolean water = cur.getBlock() == Blocks.WATER;
            boolean lava = cur.getBlock() == Blocks.LAVA;
            if (!water && !lava) continue;
            if (water && !Configs.DRAIN_WATER.getBooleanValue()) continue;
            if (lava && !Configs.DRAIN_LAVA.getBooleanValue()) continue;
            if (!StateMatcher.isFluidSource(ctx.world, pos) && !Configs.DRAIN_FLOWING.getBooleanValue()) continue;

            if (!cover) {
                // 空桶右键流体源：服务端会移除源并给玩家装满的桶
                ctx.queue.submit(WorkQueue.Task.drain(pos));
                return true;
            }

            PlacementHelper.Support support = PlacementHelper.findSupport(ctx.world, pos);
            if (support == null) support = PlacementHelper.virtualSupport(pos);
            BlockState coverState = coverItem instanceof BlockItem blockItem
                    ? blockItem.getBlock().getDefaultState() : null;

            if (Configs.DRAIN_REMOVE_COVER.getBooleanValue()) {
                ctx.queue.submitAll(
                        WorkQueue.Task.place(pos, coverItem, support, coverState),
                        WorkQueue.Task.brk(pos, WorkQueue.Type.BREAK));
            } else {
                ctx.queue.submit(WorkQueue.Task.place(pos, coverItem, support, coverState));
            }
            return true;
        }
        return false;
    }
}
