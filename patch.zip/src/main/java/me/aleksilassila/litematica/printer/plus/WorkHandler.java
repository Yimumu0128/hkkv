package me.aleksilassila.litematica.printer.plus;

/** 一个工作模式 = 一个处理器。返回 true 表示本 tick 已经提交了一个动作。 */
public interface WorkHandler {
    String name();

    boolean isEnabled();

    boolean tick(WorkContext ctx);
}
