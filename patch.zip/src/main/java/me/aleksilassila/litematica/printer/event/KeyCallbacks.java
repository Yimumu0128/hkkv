package me.aleksilassila.litematica.printer.event;

import fi.dy.masa.malilib.hotkeys.KeyCallbackToggleBooleanConfigWithMessage;
import me.aleksilassila.litematica.printer.config.Configs;
import me.aleksilassila.litematica.printer.config.Hotkeys;
import net.minecraft.client.MinecraftClient;

/** 把每个新模式开关绑定到对应 ConfigBoolean。 */
public class KeyCallbacks {
    public static void init(MinecraftClient mc) {
        Hotkeys.TOGGLE_PRINTING_MODE.getKeybind()
                .setCallback(new KeyCallbackToggleBooleanConfigWithMessage(Configs.PRINT_MODE));
        Hotkeys.TOGGLE_FILL.getKeybind()
                .setCallback(new KeyCallbackToggleBooleanConfigWithMessage(Configs.ENABLE_FILL));
        Hotkeys.TOGGLE_FLUID.getKeybind()
                .setCallback(new KeyCallbackToggleBooleanConfigWithMessage(Configs.ENABLE_FLUID_DRAIN));
        Hotkeys.TOGGLE_MINE.getKeybind()
                .setCallback(new KeyCallbackToggleBooleanConfigWithMessage(Configs.ENABLE_MINE));
        Hotkeys.TOGGLE_BEDROCK.getKeybind()
                .setCallback(new KeyCallbackToggleBooleanConfigWithMessage(Configs.ENABLE_BEDROCK));
        Hotkeys.TOGGLE_AIR.getKeybind()
                .setCallback(new KeyCallbackToggleBooleanConfigWithMessage(Configs.PRINT_IN_AIR));
        // 紧急停止：置位内部 flag，由 PrinterPlus 在下一个 client tick 处理
        Hotkeys.EMERGENCY_STOP.getKeybind()
                .setCallback(new KeyCallbackToggleBooleanConfigWithMessage(Configs.EMERGENCY_STOP_FLAG));
    }
}
