package me.aleksilassila.litematica.printer.plus;

import net.minecraft.util.math.BlockPos;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;

/**
 * 读取 Forgematica 当前选区的包围盒。
 *
 * Forgematica 0.1.12 的选区 API 在不同移植分支里方法名不完全一致
 * （AreaSelectionManager / SelectionManager、getAllSubRegionBoxes / getSubRegionBoxes 等），
 * 所以这里用反射做一次适配：编译期不依赖具体签名，运行时按候选名依次尝试。
 * 拿到后调用方可换成直接调用以提速。
 *
 * 反射失败时返回空列表，CoordinateScanner 会自动回退到「玩家周围打印半径」范围。
 */
public final class SelectionProvider {
    private static final Logger LOGGER = LogManager.getLogger("ForgematicaPrinterPlus/Selection");

    public static final class Box {
        public final BlockPos min;
        public final BlockPos max;

        public Box(BlockPos a, BlockPos b) {
            this.min = new BlockPos(Math.min(a.getX(), b.getX()), Math.min(a.getY(), b.getY()), Math.min(a.getZ(), b.getZ()));
            this.max = new BlockPos(Math.max(a.getX(), b.getX()), Math.max(a.getY(), b.getY()), Math.max(a.getZ(), b.getZ()));
        }

        public boolean contains(BlockPos p) {
            return p.getX() >= min.getX() && p.getX() <= max.getX()
                    && p.getY() >= min.getY() && p.getY() <= max.getY()
                    && p.getZ() >= min.getZ() && p.getZ() <= max.getZ();
        }
    }

    public List<Box> boxes() {
        List<Box> result = new ArrayList<>();
        try {
            Class<?> dm = Class.forName("fi.dy.masa.litematica.data.DataManager");
            Object manager = invokeStaticAny(dm, "getAreaSelectionManager", "getSelectionManager");
            if (manager == null) return result;

            Object selection = invokeAny(manager, "getCurrentSelection", "getSelection", "getCurrentAreaSelection");
            if (selection == null) return result;

            Object raw = invokeAny(selection, "getAllSubRegionBoxes", "getSubRegionBoxes", "getAllBoxes", "getBoxes");
            Iterable<?> items = toIterable(raw);
            for (Object box : items) {
                if (box == null) continue;
                Object p1 = invokeAny(box, "getPos1", "getCorner1", "getMinPos");
                Object p2 = invokeAny(box, "getPos2", "getCorner2", "getMaxPos");
                if (p1 instanceof BlockPos a && p2 instanceof BlockPos b) {
                    result.add(new Box(a, b));
                }
            }
        } catch (Throwable t) {
            // 选区 API 变化不应该让游戏崩溃：记一条日志后走范围回退
            LOGGER.debug("Forgematica selection lookup failed, falling back to radius scan: {}", t.toString());
        }
        return result;
    }

    private static Iterable<?> toIterable(Object raw) {
        if (raw instanceof Iterable<?> it) return it;
        if (raw instanceof Map<?, ?> map) return map.values();
        if (raw instanceof Collection<?> col) return col;
        if (raw != null && raw.getClass().isArray()) return java.util.Arrays.asList((Object[]) raw);
        return java.util.Collections.emptyList();
    }

    private static Object invokeStaticAny(Class<?> owner, String... names) {
        for (String n : names) {
            try {
                Method m = owner.getMethod(n);
                m.setAccessible(true);
                return m.invoke(null);
            } catch (ReflectiveOperationException ignored) {
            }
        }
        return null;
    }

    private static Object invokeAny(Object target, String... names) {
        for (String n : names) {
            try {
                Method m = target.getClass().getMethod(n);
                m.setAccessible(true);
                return m.invoke(target);
            } catch (ReflectiveOperationException ignored) {
            }
        }
        return null;
    }
}
