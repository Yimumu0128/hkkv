package me.aleksilassila.litematica.printer.config;

import com.google.common.collect.ImmutableList;
import fi.dy.masa.malilib.config.IConfigBase;
import fi.dy.masa.malilib.config.options.ConfigBoolean;
import fi.dy.masa.malilib.config.options.ConfigDouble;
import fi.dy.masa.malilib.config.options.ConfigInteger;
import fi.dy.masa.malilib.config.options.ConfigString;
import me.aleksilassila.litematica.printer.PrinterReference;

import java.util.List;

/**
 * ForgematicaPrinter 1.20.1 Forge 二改配置表。
 *
 * 本文件替换基线同名文件。所有新选项都会通过 ConfigsMixin 的 Redirect 追加到
 * Forgematica 的 Generic 配置列表，因此出现在 M + C -> 通用(Generic) 页底部。
 * 选项说明直接写在 comment 里（MaLiLib 鼠标悬停显示），不依赖语言文件键名。
 *
 * 许可：AGPL-3.0-only（与基线一致）。
 */
public class Configs {
    private static final String GENERIC_KEY = PrinterReference.MOD_KEY + ".config.generic";

    // ------------------------------------------------------------------
    // 基线原有选项（保持字段名不变，ConfigsMixin 依赖 getConfigList）
    // ------------------------------------------------------------------
    public static final ConfigInteger PRINTING_INTERVAL = new ConfigInteger("printingInterval", 12, 1, 40,
            "打印间隔(tick)。数值越小越快，出现幽灵方块/朝向错误时调大。");
    public static final ConfigDouble PRINTING_RANGE = new ConfigDouble("printingRange", 5, 2.5, 5,
            "打印作用半径(格)。服务器上建议调小。");
    public static final ConfigBoolean PRINT_MODE = new ConfigBoolean("printingMode", false,
            "原版打印模式开关。使用本二改的新模式时建议关闭，避免两套逻辑互相抢坐标。");
    public static final ConfigBoolean PRINT_DEBUG = new ConfigBoolean("printingDebug", false,
            "输出调试日志。");
    public static final ConfigBoolean REPLACE_FLUIDS_SOURCE_BLOCKS = new ConfigBoolean("replaceFluidSourceBlocks", true,
            "原版打印时是否替换流体源方块。");
    public static final ConfigBoolean STRIP_LOGS = new ConfigBoolean("stripLogs", true,
            "缺少去皮原木时，用普通原木 + 斧头去皮。");
    public static final ConfigBoolean INTERACT_BLOCKS = new ConfigBoolean("interactBlocks", true,
            "原版打印时是否设置方块状态。");

    // ------------------------------------------------------------------
    // 通用 / 安全
    // ------------------------------------------------------------------
    public static final ConfigBoolean DESTRUCTIVE_MODE = new ConfigBoolean("destructiveMode", false,
            "⚠ 破坏性模式总闸。关闭时：挖掘、破基岩、破冰纠错全部不执行。开启前务必备份存档。");
    public static final ConfigInteger WORK_INTERVAL = new ConfigInteger("workInterval", 4, 1, 40,
            "新模式工作间隔(tick)。反作弊/放置速率限制严格时调大。");
    public static final ConfigInteger SCAN_BUDGET = new ConfigInteger("scanBudget", 256, 16, 4096,
            "每次扫描最多检查的坐标数，防止大投影卡帧。");
    public static final ConfigInteger SCAN_MAX_POSITIONS = new ConfigInteger("scanMaxPositions", 200000, 1000, 2000000,
            "选区展开成坐标表的上限，超过会截断并输出警告。");
    public static final ConfigInteger PLACEMENT_TIMEOUT = new ConfigInteger("placementTimeout", 40, 5, 200,
            "等待服务端确认方块更新的 tick 数，超时重试。");
    public static final ConfigInteger PLACEMENT_RETRIES = new ConfigInteger("placementRetries", 3, 0, 10,
            "单个动作失败后的最大重试次数。");
    public static final ConfigBoolean MATCH_SAME_ITEM = new ConfigBoolean("matchSameItem", true,
            "宽松状态比对：同种方块即视为匹配，忽略投影里不存在的属性（兼容方块替换类 mod）。");
    public static final ConfigBoolean SHOW_CHAT_WARNINGS = new ConfigBoolean("showChatWarnings", true,
            "在聊天栏提示缺材料、缺配套 mod、破坏性模式警告。");

    // 内部状态：紧急停止热键写入，不显示到配置界面
    public static final ConfigBoolean EMERGENCY_STOP_FLAG = new ConfigBoolean("emergencyStopFlag", false,
            "internal");

    // ------------------------------------------------------------------
    // 选区填充（Fill）
    // ------------------------------------------------------------------
    public static final ConfigBoolean ENABLE_FILL = new ConfigBoolean("enableFill", false,
            "选区填充：用指定方块填满 Forgematica 选区 / 玩家范围。");
    public static final ConfigBoolean FILL_USE_SELECTION = new ConfigBoolean("fillUseSelection", true,
            "true=用 Forgematica 选区；false=用玩家周围打印半径范围。");
    public static final ConfigBoolean FILL_HAND_HELD = new ConfigBoolean("fillHandHeld", false,
            "true=用主手物品填充；false=用 fillBlock 指定的方块。");
    public static final ConfigString FILL_BLOCK = new ConfigString("fillBlock", "minecraft:stone",
            "填充用的方块/物品 ID，例如 minecraft:stone。");
    public static final ConfigString FILL_REPLACE_MODE = new ConfigString("fillReplaceMode", "AIR_ONLY",
            "AIR_ONLY=只填空气；ANY=替换除基岩外的任意方块。");
    public static final ConfigInteger FILL_PER_TICK = new ConfigInteger("fillPerTick", 1, 1, 16,
            "每个工作周期最多提交的填充任务数。");

    // ------------------------------------------------------------------
    // 流体排空（Fluid）
    // ------------------------------------------------------------------
    public static final ConfigBoolean ENABLE_FLUID_DRAIN = new ConfigBoolean("enableFluidDrain", false,
            "排流体：自动清掉选区内的水/岩浆源。");
    public static final ConfigBoolean FLUID_USE_SELECTION = new ConfigBoolean("fluidUseSelection", true,
            "true=用选区；false=用玩家周围范围。");
    public static final ConfigBoolean DRAIN_WATER = new ConfigBoolean("drainWater", true,
            "处理水源。");
    public static final ConfigBoolean DRAIN_LAVA = new ConfigBoolean("drainLava", true,
            "处理岩浆源。");
    public static final ConfigBoolean DRAIN_FLOWING = new ConfigBoolean("drainFlowing", false,
            "同时处理流动液体（桶模式对流动液体通常无效，会自动超时跳过）。");
    public static final ConfigString DRAIN_METHOD = new ConfigString("drainMethod", "BUCKET",
            "BUCKET=空桶右键装走流体源（需背包有空桶）；COVER=放实心方块挤掉流体源。");
    public static final ConfigString DRAIN_COVER_BLOCK = new ConfigString("drainCoverBlock", "minecraft:stone",
            "COVER 模式用的实心方块 ID。");
    public static final ConfigBoolean DRAIN_REMOVE_COVER = new ConfigBoolean("drainRemoveCover", true,
            "COVER 模式排空后把覆盖方块挖掉。⚠ 属于破坏性操作。");

    // ------------------------------------------------------------------
    // 挖掘模式（Mine）
    // ------------------------------------------------------------------
    public static final ConfigBoolean ENABLE_MINE = new ConfigBoolean("enableMine", false,
            "⚠ 挖掘模式：一键挖掉选区/范围内全部方块，需 destructiveMode 开启。");
    public static final ConfigBoolean MINE_USE_SELECTION = new ConfigBoolean("mineUseSelection", true,
            "true=用选区；false=用玩家周围范围。");
    public static final ConfigString MINE_FILTER = new ConfigString("mineFilter", "ALL",
            "ALL=全部；EXTRA_ONLY=只挖投影外的多余方块；WRONG_STATE_ONLY=只挖状态不符的方块。");
    public static final ConfigBoolean MINE_CHECK_HARDNESS = new ConfigBoolean("mineCheckHardness", true,
            "生存模式跳过硬度为负（不可破坏）的方块。");
    public static final ConfigBoolean MINE_AUTO_TOOL = new ConfigBoolean("mineAutoTool", true,
            "挖掘前尝试把快捷栏里的工具切到主手。");
    public static final ConfigBoolean MINE_INSTANT_CREATIVE = new ConfigBoolean("mineInstantCreative", true,
            "创造模式瞬挖（一次性 attackBlock）。");
    public static final ConfigString MINE_WHITELIST = new ConfigString("mineWhitelist", "",
            "方块 ID 白名单，逗号分隔；留空表示不限制。");
    public static final ConfigString MINE_BLACKLIST = new ConfigString("mineBlacklist", "minecraft:bedrock",
            "方块 ID 黑名单，逗号分隔；默认排除基岩。");

    // ------------------------------------------------------------------
    // 破基岩模式（Bedrock，需要配套破基岩 mod）
    // ------------------------------------------------------------------
    public static final ConfigBoolean ENABLE_BEDROCK = new ConfigBoolean("enableBedrock", false,
            "⚠ 破基岩模式：需 destructiveMode 开启 + 安装配套破基岩 mod。");
    public static final ConfigBoolean BEDROCK_USE_SELECTION = new ConfigBoolean("bedrockUseSelection", true,
            "true=用选区；false=用玩家周围范围。");
    public static final ConfigString BEDROCK_MOD_ID = new ConfigString("bedrockModId", "bedrockbreaker",
            "配套破基岩 mod 的 modId（Forge 1.20.1 无 Fabric-Bedrock-Miner，需自行准备）。");
    public static final ConfigString BEDROCK_ALLOWLIST = new ConfigString("bedrockAllowlist", "",
            "白名单方块 ID，逗号分隔；留空表示只处理基岩本身。");
    public static final ConfigString BEDROCK_API_CLASS = new ConfigString("bedrockApiClass", "",
            "可选：配套 mod 暴露的静态类名，含 public static void breakBlock(BlockPos)。留空则退化为 attackBlock。");

    // ------------------------------------------------------------------
    // 特殊方块兼容
    // ------------------------------------------------------------------
    public static final ConfigBoolean HANDLE_WATERLOGGED = new ConfigBoolean("handleWaterlogged", false,
            "含水方块：先在目标格放水，再放入方块使其自动含水；已放好但不含水的方块会拆掉重来（⚠破坏性）。");
    public static final ConfigBoolean REPLACE_DEAD_CORAL = new ConfigBoolean("replaceDeadCoral", false,
            "珊瑚替换：投影里的死珊瑚自动用对应活珊瑚打印。");
    public static final ConfigBoolean ICE_CORRECTION = new ConfigBoolean("iceCorrection", false,
            "⚠ 冰处理自动纠错：破冰后放水（高危，需 destructiveMode）。");
    public static final ConfigBoolean SPECIAL_USE_SELECTION = new ConfigBoolean("specialUseSelection", false,
            "特殊方块处理是否限制在选区内；false=扫描玩家周围投影范围。");

    // ------------------------------------------------------------------
    // 凭空放置（printInAir）
    // ------------------------------------------------------------------
    public static final ConfigBoolean PRINT_IN_AIR = new ConfigBoolean("printInAir", false,
            "⚠ 实验性：投影里无支撑的方块也尝试发包放置。原版服务端可能直接拒绝。");
    public static final ConfigString PRINT_IN_AIR_MODE = new ConfigString("printInAirMode", "PACKET",
            "PACKET=自行发静默视角+交互包；TWEAKERGE=仅在检测到 Tweakerge 时启用。");
    public static final ConfigBoolean PRINT_IN_AIR_USE_SELECTION = new ConfigBoolean("printInAirUseSelection", false,
            "true=用选区；false=用玩家周围范围。");

    /** 所有需要出现在 M+C -> 通用页底部的选项。 */
    public static ImmutableList<IConfigBase> getConfigList() {
        List<IConfigBase> list = new java.util.ArrayList<>(fi.dy.masa.litematica.config.Configs.Generic.OPTIONS);

        // 基线原有
        list.add(PRINT_MODE);
        list.add(PRINT_DEBUG);
        list.add(PRINTING_INTERVAL);
        list.add(PRINTING_RANGE);
        list.add(REPLACE_FLUIDS_SOURCE_BLOCKS);
        list.add(STRIP_LOGS);
        list.add(INTERACT_BLOCKS);

        // 通用 / 安全
        list.add(DESTRUCTIVE_MODE);
        list.add(WORK_INTERVAL);
        list.add(SCAN_BUDGET);
        list.add(SCAN_MAX_POSITIONS);
        list.add(PLACEMENT_TIMEOUT);
        list.add(PLACEMENT_RETRIES);
        list.add(MATCH_SAME_ITEM);
        list.add(SHOW_CHAT_WARNINGS);

        // 填充
        list.add(ENABLE_FILL);
        list.add(FILL_USE_SELECTION);
        list.add(FILL_HAND_HELD);
        list.add(FILL_BLOCK);
        list.add(FILL_REPLACE_MODE);
        list.add(FILL_PER_TICK);

        // 流体
        list.add(ENABLE_FLUID_DRAIN);
        list.add(FLUID_USE_SELECTION);
        list.add(DRAIN_WATER);
        list.add(DRAIN_LAVA);
        list.add(DRAIN_FLOWING);
        list.add(DRAIN_METHOD);
        list.add(DRAIN_COVER_BLOCK);
        list.add(DRAIN_REMOVE_COVER);

        // 挖掘
        list.add(ENABLE_MINE);
        list.add(MINE_USE_SELECTION);
        list.add(MINE_FILTER);
        list.add(MINE_CHECK_HARDNESS);
        list.add(MINE_AUTO_TOOL);
        list.add(MINE_INSTANT_CREATIVE);
        list.add(MINE_WHITELIST);
        list.add(MINE_BLACKLIST);

        // 破基岩
        list.add(ENABLE_BEDROCK);
        list.add(BEDROCK_USE_SELECTION);
        list.add(BEDROCK_MOD_ID);
        list.add(BEDROCK_ALLOWLIST);
        list.add(BEDROCK_API_CLASS);

        // 特殊方块
        list.add(HANDLE_WATERLOGGED);
        list.add(REPLACE_DEAD_CORAL);
        list.add(ICE_CORRECTION);
        list.add(SPECIAL_USE_SELECTION);

        // 凭空放置
        list.add(PRINT_IN_AIR);
        list.add(PRINT_IN_AIR_MODE);
        list.add(PRINT_IN_AIR_USE_SELECTION);

        return ImmutableList.copyOf(list);
    }
}
