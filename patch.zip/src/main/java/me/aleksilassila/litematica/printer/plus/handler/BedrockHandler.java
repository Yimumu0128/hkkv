package me.aleksilassila.litematica.printer.plus.handler;

import me.aleksilassila.litematica.printer.config.Configs;
import me.aleksilassila.litematica.printer.plus.Chats;
import me.aleksilassila.litematica.printer.plus.CoordinateScanner;
import me.aleksilassila.litematica.printer.plus.InventoryBridge;
import me.aleksilassila.litematica.printer.plus.WorkContext;
import me.aleksilassila.litematica.printer.plus.WorkHandler;
import me.aleksilassila.litematica.printer.plus.WorkQueue;
import net.minecraft.block.Blocks;
import net.minecraft.util.math.BlockPos;
import net.minecraftforge.fml.ModList;

import java.util.List;
import java.util.Set;

/**
 * 破基岩模式：把选区内的基岩交给配套破基岩 mod。
 * Forge 1.20.1 没有 Fabric-Bedrock-Miner；缺失配套 mod 时整组不工作并提示。
 */
public final class BedrockHandler implements WorkHandler {
    private final CoordinateScanner scanner = new CoordinateScanner();
    private boolean warnedMissingMod;

    @Override
    public String name() { return "Bedrock"; }

    @Override
    public boolean isEnabled() {
        return Configs.ENABLE_BEDROCK.getBooleanValue() && Configs.DESTRUCTIVE_MODE.getBooleanValue();
    }

    @Override
    public boolean tick(WorkContext ctx) {
        if (!companionLoaded()) {
            if (!warnedMissingMod) {
                Chats.say(ctx, "破基岩需要配套 mod（bedrockModId 当前为 "
                        + Configs.BEDROCK_MOD_ID.getStringValue() + "），未检测到，已跳过");
                warnedMissingMod = true;
            }
            return false;
        }
        warnedMissingMod = false;

        List<BlockPos> coords = scanner.next(ctx, Configs.BEDROCK_USE_SELECTION.getBooleanValue(),
                Math.max(1, Configs.SCAN_BUDGET.getIntegerValue()));
        Set<String> extra = InventoryBridge.parseIdList(Configs.BEDROCK_ALLOWLIST.getStringValue());

        for (BlockPos pos : coords) {
            if (!ctx.inReach(pos)) continue;
            String id = InventoryBridge.blockId(ctx.world.getBlockState(pos).getBlock());
            boolean bedrock = ctx.world.getBlockState(pos).getBlock() == Blocks.BEDROCK;
            if (!bedrock && !extra.contains(id)) continue;

            ctx.queue.submit(WorkQueue.Task.brk(pos, WorkQueue.Type.BEDROCK));
            return true;
        }
        return false;
    }

    private static boolean companionLoaded() {
        try {
            return ModList.get().isLoaded(Configs.BEDROCK_MOD_ID.getStringValue());
        } catch (Throwable t) {
            return false;
        }
    }
}
