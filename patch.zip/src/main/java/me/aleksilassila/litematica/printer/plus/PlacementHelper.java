package me.aleksilassila.litematica.printer.plus;

import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.world.World;

/** 为放置动作找一个合法的点击面。 */
public final class PlacementHelper {
    private PlacementHelper() {}

    public static final class Support {
        public final BlockPos clickPos;
        public final Direction side;

        public Support(BlockPos clickPos, Direction side) {
            this.clickPos = clickPos;
            this.side = side;
        }
    }

    /** 找一个相邻实心方块，返回的 side 指向目标格：clickPos.offset(side) == pos。 */
    public static Support findSupport(World world, BlockPos pos) {
        for (Direction d : Direction.values()) {
            BlockPos neighbor = pos.offset(d);
            BlockState state = world.getBlockState(neighbor);
            if (state.isAir()) continue;
            if (state.getBlock() == Blocks.WATER || state.getBlock() == Blocks.LAVA) continue;
            return new Support(neighbor, d.getOpposite());
        }
        return null;
    }

    /** 没有真实支撑时用的虚拟命中（凭空放置实验路径，服务端可能拒绝）。 */
    public static Support virtualSupport(BlockPos pos) {
        return new Support(pos.offset(Direction.DOWN), Direction.UP);
    }
}
