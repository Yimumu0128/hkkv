package me.aleksilassila.litematica.printer.plus;

import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.item.Item;
import net.minecraft.registry.Registries;
import net.minecraft.util.Identifier;

/**
 * 死珊瑚 -> 活珊瑚。
 *
 * 原版命名规律：dead_brain_coral(_block / _fan / _wall_fan) -> brain_coral(...)，
 * 因此只需去掉 dead_ 前缀，无需维护 20 条映射表。
 */
public final class CoralMapper {
    private CoralMapper() {}

    public static boolean isDead(Block block) {
        Identifier id = Registries.BLOCK.getId(block);
        return "minecraft".equals(id.getNamespace()) && id.getPath().startsWith("dead_");
    }

    public static Block live(Block dead) {
        Identifier id = Registries.BLOCK.getId(dead);
        String path = id.getPath();
        if (!"minecraft".equals(id.getNamespace()) || !path.startsWith("dead_")) return dead;
        try {
            Block live = Registries.BLOCK.get(new Identifier("minecraft", path.substring(5)));
            return live == Blocks.AIR ? dead : live;
        } catch (RuntimeException e) {
            return dead;
        }
    }

    public static Item liveItem(Block dead) {
        return live(dead).asItem();
    }
}
