package me.aleksilassila.litematica.printer.plus;

import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.Registries;
import net.minecraft.util.Hand;
import net.minecraft.util.Identifier;

import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.Set;

/** 把需要的物品切到主手；生存模式只搜快捷栏，创造模式直接补一个。 */
public final class InventoryBridge {
    private InventoryBridge() {}

    public static boolean select(WorkContext ctx, Item item) {
        if (item == null) return true;
        PlayerInventory inv = ctx.player.getInventory();

        for (int i = 0; i < 9; i++) {
            ItemStack stack = inv.getStack(i);
            if (!stack.isEmpty() && stack.getItem() == item) {
                inv.selectedSlot = i;
                return true;
            }
        }

        if (ctx.player.getAbilities().creativeMode) {
            int slot = inv.selectedSlot;
            inv.setStack(slot, new ItemStack(item));
            // 与基线 PrepareAction 一致：把创造模式物品栏改动同步给服务端
            ctx.mc.interactionManager.clickCreativeStack(ctx.player.getStackInHand(Hand.MAIN_HAND), 36 + slot);
            return true;
        }
        return false;
    }

    /** 支持方块 ID 与物品 ID；无法解析返回 null。 */
    public static Item parseItem(String raw) {
        if (raw == null || raw.isBlank()) return null;
        try {
            Identifier id = new Identifier(raw.trim());
            Item item = Registries.ITEM.get(id);
            if (item != Items.AIR) return item;
            Block block = Registries.BLOCK.get(id);
            if (block != Blocks.AIR) return block.asItem();
        } catch (RuntimeException ignored) {
        }
        return null;
    }

    public static Block parseBlock(String raw) {
        if (raw == null || raw.isBlank()) return null;
        try {
            Block block = Registries.BLOCK.get(new Identifier(raw.trim()));
            return block == Blocks.AIR ? null : block;
        } catch (RuntimeException ignored) {
            return null;
        }
    }

    /** 逗号分隔的方块 ID 列表，用于挖掘/破基岩白黑名单。 */
    public static Set<String> parseIdList(String raw) {
        if (raw == null || raw.isBlank()) return Collections.emptySet();
        Set<String> out = new LinkedHashSet<>();
        for (String part : raw.split(",")) {
            String s = part.trim();
            if (!s.isEmpty()) out.add(s);
        }
        return out;
    }

    public static String blockId(Block block) {
        return Registries.BLOCK.getId(block).toString();
    }
}
