package me.aleksilassila.litematica.printer.plus;

import me.aleksilassila.litematica.printer.config.Configs;
import net.minecraft.text.Text;

/** 游戏内提示（受 showChatWarnings 控制）。 */
public final class Chats {
    private Chats() {}

    public static void say(WorkContext ctx, String message) {
        if (!Configs.SHOW_CHAT_WARNINGS.getBooleanValue() || ctx == null) return;
        ctx.mc.inGameHud.getChatHud().addMessage(Text.literal("§6[Printer+] §r" + message));
    }
}
