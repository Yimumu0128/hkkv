package me.aleksilassila.litematica.printer.plus.handler;

import me.aleksilassila.litematica.printer.config.Configs;
import me.aleksilassila.litematica.printer.plus.CoordinateScanner;
import me.aleksilassila.litematica.printer.plus.CoralMapper;
import me.aleksilassila.litematica.printer.plus.PlacementHelper;
import me.aleksilassila.litematica.printer.plus.StateMatcher;
import me.aleksilassila.litematica.printer.plus.WorkContext;
import me.aleksilassila.litematica.printer.plus.WorkHandler;
import me.aleksilassila.litematica.printer.plus.WorkQueue;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.util.math.BlockPos;

import java.util.List;

/** 含水方块 / 死珊瑚替换 / 破冰放水（后两者带破坏性）。 */
public final class SpecialBlocksHandler implements WorkHandler {
    private final CoordinateScanner scanner = new CoordinateScanner();

    @Override
    public String name() { return "SpecialBlocks"; }

    @Override
    public boolean isEnabled() {
        return Configs.HANDLE_WATERLOGGED.getBooleanValue()
                || Configs.REPLACE_DEAD_CORAL.getBooleanValue()
                || Configs.ICE_CORRECTION.getBooleanValue();
    }

    @Override
    public boolean tick(WorkContext ctx) {
        List<BlockPos> coords = scanner.next(ctx, Configs.SPECIAL_USE_SELECTION.getBooleanValue(),
                Math.max(1, Configs.SCAN_BUDGET.getIntegerValue()));

        for (BlockPos pos : coords) {
            if (!ctx.inReach(pos)) continue;
            BlockState target = ctx.schematic == null ? null : ctx.schematic.getBlockState(pos);
            BlockState cur = ctx.world.getBlockState(pos);

            // ---- 死珊瑚 -> 活珊瑚 ----
            if (Configs.REPLACE_DEAD_CORAL.getBooleanValue()
                    && target != null && !target.isAir() && CoralMapper.isDead(target.getBlock())) {
                Block live = CoralMapper.live(target.getBlock());
                if (cur.getBlock() != live) {
                    PlacementHelper.Support support = PlacementHelper.findSupport(ctx.world, pos);
                    if (support != null) {
                        ctx.queue.submit(WorkQueue.Task.place(pos, live.asItem(), support, live.getDefaultState()));
                        return true;
                    }
                }
            }

            // ---- 含水方块：先放水再放方块，方块会自然变成 waterlogged=true ----
            if (Configs.HANDLE_WATERLOGGED.getBooleanValue()
                    && target != null && StateMatcher.isWaterlogged(target)) {
                boolean blockOk = target.getBlock() == cur.getBlock();
                boolean waterOk = StateMatcher.isWaterlogged(cur);
                if (!blockOk || !waterOk) {
                    PlacementHelper.Support support = PlacementHelper.findSupport(ctx.world, pos);
                    if (support == null) support = PlacementHelper.virtualSupport(pos);
                    Item blockItem = target.getBlock().asItem();
                    if (blockItem == Items.AIR) continue;

                    if (blockOk && !waterOk) {
                        ctx.queue.submitAll(
                                WorkQueue.Task.brk(pos, WorkQueue.Type.BREAK),
                                WorkQueue.Task.water(pos, support),
                                WorkQueue.Task.place(pos, blockItem, support, target));
                    } else {
                        ctx.queue.submitAll(
                                WorkQueue.Task.water(pos, support),
                                WorkQueue.Task.place(pos, blockItem, support, target));
                    }
                    return true;
                }
            }

            // ---- 冰处理自动纠错：破冰 + 放水（高危） ----
            if (Configs.ICE_CORRECTION.getBooleanValue()
                    && Configs.DESTRUCTIVE_MODE.getBooleanValue()
                    && StateMatcher.isIce(cur.getBlock())) {
                boolean needsWater = target != null
                        && (StateMatcher.isWaterlogged(target) || target.getBlock() == Blocks.WATER);
                if (needsWater) {
                    PlacementHelper.Support support = PlacementHelper.findSupport(ctx.world, pos);
                    if (support == null) support = PlacementHelper.virtualSupport(pos);
                    ctx.queue.submitAll(
                            WorkQueue.Task.brk(pos, WorkQueue.Type.ICE_BREAK),
                            WorkQueue.Task.water(pos, support));
                    return true;
                }
            }
        }
        return false;
    }
}
