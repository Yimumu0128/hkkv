package me.aleksilassila.litematica.printer.plus;

import me.aleksilassila.litematica.printer.config.Configs;
import net.minecraft.client.MinecraftClient;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.TickEvent;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/** Forge 事件总线入口：驱动全部新工作模式。 */
public final class PrinterPlus {
    private static final Logger LOGGER = LogManager.getLogger("ForgematicaPrinterPlus");
    private static WorkContext context;
    private static long tick;

    private PrinterPlus() {}

    public static void register() {
        MinecraftForge.EVENT_BUS.addListener(PrinterPlus::onClientTick);
        LOGGER.info("ForgematicaPrinter Plus modes registered (fill / fluid / mine / bedrock / special / air)");
    }

    private static void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;

        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc == null || mc.player == null || mc.world == null) return;

        if (context == null || context.player != mc.player) {
            context = new WorkContext(mc);
        }
        context.tickCounter = ++tick;
        context.refresh();

        if (Configs.EMERGENCY_STOP_FLAG.getBooleanValue()) {
            emergencyStop();
            return;
        }

        int interval = Math.max(1, Configs.WORK_INTERVAL.getIntegerValue());
        if (tick % interval != 0) return;

        // 串行：先处理/确认当前动作，队列空了才允许下一个处理器提交
        context.queue.tick(context);
        if (!context.queue.isIdle()) return;

        for (WorkHandler handler : context.handlers) {
            if (handler.isEnabled() && handler.tick(context)) return;
        }
    }

    private static void emergencyStop() {
        if (context != null) context.queue.clear();
        Configs.ENABLE_FILL.setBooleanValue(false);
        Configs.ENABLE_FLUID_DRAIN.setBooleanValue(false);
        Configs.ENABLE_MINE.setBooleanValue(false);
        Configs.ENABLE_BEDROCK.setBooleanValue(false);
        Configs.PRINT_IN_AIR.setBooleanValue(false);
        Configs.EMERGENCY_STOP_FLAG.setBooleanValue(false);
        if (context != null) Chats.say(context, "紧急停止：任务队列已清空，全部模式已关闭");
        LOGGER.warn("Emergency stop triggered");
    }
}
