package me.aleksilassila.litematica.printer.plus;

import fi.dy.masa.litematica.data.DataManager;
import me.aleksilassila.litematica.printer.config.Configs;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/**
 * 跨 tick 的坐标游标：把选区 / 玩家范围展开成坐标表，每个工作周期只取 scanBudget 个，
 * 大投影不会一帧遍历完导致卡死。缓存会周期性重建，以感知世界变化。
 */
public final class CoordinateScanner {
    private static final Logger LOGGER = LogManager.getLogger("ForgematicaPrinterPlus/Scan");
    private static final long REBUILD_TICKS = 200;

    private final SelectionProvider selection = new SelectionProvider();
    private final List<BlockPos> cache = new ArrayList<>();
    private int cursor = 0;
    private long builtAt = -1;
    private String key = "";
    private boolean warnedTruncate = false;

    public void invalidate() {
        builtAt = -1;
    }

    public List<BlockPos> next(WorkContext ctx, boolean useSelection, int budget) {
        String newKey = (useSelection ? "sel" : "area") + "|" + ctx.player.getBlockPos() + "|"
                + Configs.PRINTING_RANGE.getDoubleValue();
        if (builtAt < 0 || ctx.tickCounter - builtAt > REBUILD_TICKS || !key.equals(newKey)) {
            rebuild(ctx, useSelection, newKey);
        }

        List<BlockPos> out = new ArrayList<>(Math.min(budget, cache.size()));
        while (cursor < cache.size() && out.size() < budget) {
            out.add(cache.get(cursor++));
        }
        if (cursor >= cache.size()) {
            cursor = 0;                 // 循环扫描：世界状态每次都会重新判定
        }
        return out;
    }

    private void rebuild(WorkContext ctx, boolean useSelection, String newKey) {
        cache.clear();
        cursor = 0;
        key = newKey;
        builtAt = ctx.tickCounter;
        int limit = Configs.SCAN_MAX_POSITIONS.getIntegerValue();

        if (useSelection) {
            List<SelectionProvider.Box> boxes = selection.boxes();
            outer:
            for (SelectionProvider.Box box : boxes) {
                for (int x = box.min.getX(); x <= box.max.getX(); x++) {
                    for (int y = box.min.getY(); y <= box.max.getY(); y++) {
                        for (int z = box.min.getZ(); z <= box.max.getZ(); z++) {
                            cache.add(new BlockPos(x, y, z));
                            if (cache.size() >= limit) {
                                if (!warnedTruncate) {
                                    LOGGER.warn("Selection exceeds scanMaxPositions ({}), truncating. Raise the config value if needed.", limit);
                                    warnedTruncate = true;
                                }
                                break outer;
                            }
                        }
                    }
                }
            }
        }

        // 没拿到选区、或选区为空时回退到玩家周围范围（与基线 Printer.getReachablePositions 同逻辑）
        if (cache.isEmpty()) {
            buildAroundPlayer(ctx, limit);
        }

        Vec3d from = ctx.player.getPos();
        cache.sort(Comparator.comparingDouble(p -> from.squaredDistanceTo(Vec3d.ofCenter(p))));
    }

    private void buildAroundPlayer(WorkContext ctx, int limit) {
        double r = Configs.PRINTING_RANGE.getDoubleValue();
        int max = (int) Math.ceil(r);
        double r2 = r * r;
        BlockPos origin = ctx.player.getBlockPos();

        for (int y = -max; y <= max; y++) {
            for (int x = -max; x <= max; x++) {
                for (int z = -max; z <= max; z++) {
                    if (cache.size() >= limit) return;
                    BlockPos p = origin.north(x).west(z).up(y);
                    if (!DataManager.getRenderLayerRange().isPositionWithinRange(p)) continue;
                    if (ctx.player.getEyePos().squaredDistanceTo(Vec3d.ofCenter(p)) > r2) continue;
                    cache.add(p);
                }
            }
        }
    }
}
