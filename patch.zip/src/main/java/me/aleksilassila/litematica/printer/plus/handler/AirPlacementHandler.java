package me.aleksilassila.litematica.printer.plus.handler;

import me.aleksilassila.litematica.printer.config.Configs;
import me.aleksilassila.litematica.printer.plus.Chats;
import me.aleksilassila.litematica.printer.plus.CoordinateScanner;
import me.aleksilassila.litematica.printer.plus.PlacementHelper;
import me.aleksilassila.litematica.printer.plus.WorkContext;
import me.aleksilassila.litematica.printer.plus.WorkHandler;
import me.aleksilassila.litematica.printer.plus.WorkQueue;
import net.minecraft.block.BlockState;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.util.math.BlockPos;
import net.minecraftforge.fml.ModList;

import java.util.List;

/**
 * printInAir：对投影里「无支撑的缺失方块」也尝试发包放置。
 *
 * 原版服务端要求交互包指向一个合法点击面，纯客户端凭空发包可能被拒绝；
 * 队列超时会自动放弃并记日志。TWEAKERGE 模式仅在检测到 Tweakerge 时启用。
 */
public final class AirPlacementHandler implements WorkHandler {
    private final CoordinateScanner scanner = new CoordinateScanner();
    private boolean warnedTweakerge;

    @Override
    public String name() { return "PrintInAir"; }

    @Override
    public boolean isEnabled() { return Configs.PRINT_IN_AIR.getBooleanValue(); }

    @Override
    public boolean tick(WorkContext ctx) {
        boolean viaTweakerge = "TWEAKERGE".equalsIgnoreCase(Configs.PRINT_IN_AIR_MODE.getStringValue());
        if (viaTweakerge) {
            boolean loaded;
            try {
                loaded = ModList.get().isLoaded("tweakerge");
            } catch (Throwable t) {
                loaded = false;
            }
            if (!loaded) {
                if (!warnedTweakerge) {
                    Chats.say(ctx, "printInAirMode=TWEAKERGE 需要安装 Tweakerge（+ MaFgLib），未检测到，已跳过");
                    warnedTweakerge = true;
                }
                return false;
            }
            warnedTweakerge = false;
        }

        List<BlockPos> coords = scanner.next(ctx, Configs.PRINT_IN_AIR_USE_SELECTION.getBooleanValue(),
                Math.max(1, Configs.SCAN_BUDGET.getIntegerValue()));

        for (BlockPos pos : coords) {
            if (!ctx.inReach(pos)) continue;
            BlockState target = ctx.schematic == null ? null : ctx.schematic.getBlockState(pos);
            if (target == null || target.isAir()) continue;
            if (!ctx.world.getBlockState(pos).isAir()) continue;
            if (PlacementHelper.findSupport(ctx.world, pos) != null) continue;  // 有支撑不归本处理器管

            Item item = target.getBlock().asItem();
            if (item == Items.AIR) continue;

            PlacementHelper.Support support = PlacementHelper.virtualSupport(pos);
            ctx.queue.submit(WorkQueue.Task.place(pos, item, support, target));
            return true;
        }
        return false;
    }
}
