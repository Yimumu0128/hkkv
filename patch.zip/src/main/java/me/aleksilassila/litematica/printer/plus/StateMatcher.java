package me.aleksilassila.litematica.printer.plus;

import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.block.BlockState;
import net.minecraft.fluid.FluidState;
import net.minecraft.state.property.Properties;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

/** 投影目标状态与现实状态的比对，以及含水/冰/流体源的判定。 */
public final class StateMatcher {
    private StateMatcher() {}

    /** loose=true 时同种方块即视为匹配，避免方块替换类 mod 造成无限重放。 */
    public static boolean matches(BlockState target, BlockState actual, boolean loose) {
        if (target == null) return true;
        if (target.isAir()) return actual.isAir();
        if (loose) return target.getBlock() == actual.getBlock();
        return target.equals(actual);
    }

    public static boolean isWaterlogged(BlockState state) {
        try {
            return state.get(Properties.WATERLOGGED);
        } catch (IllegalArgumentException ignored) {
            return false;
        }
    }

    public static boolean isIce(Block block) {
        return block == Blocks.ICE || block == Blocks.PACKED_ICE || block == Blocks.BLUE_ICE;
    }

    public static boolean isWaterOrLava(Block block) {
        return block == Blocks.WATER || block == Blocks.LAVA;
    }

    /** 只认静止流体源（level 8）。流动液体用 drainFlowing 单独放行。 */
    public static boolean isFluidSource(World world, BlockPos pos) {
        FluidState fluid = world.getFluidState(pos);
        return !fluid.isEmpty() && fluid.isStill();
    }
}
