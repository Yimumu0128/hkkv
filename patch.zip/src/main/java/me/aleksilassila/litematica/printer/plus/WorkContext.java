package me.aleksilassila.litematica.printer.plus;

import fi.dy.masa.litematica.world.SchematicWorldHandler;
import fi.dy.masa.litematica.world.WorldSchematic;
import me.aleksilassila.litematica.printer.config.Configs;
import me.aleksilassila.litematica.printer.plus.handler.AirPlacementHandler;
import me.aleksilassila.litematica.printer.plus.handler.BedrockHandler;
import me.aleksilassila.litematica.printer.plus.handler.FillHandler;
import me.aleksilassila.litematica.printer.plus.handler.FluidHandler;
import me.aleksilassila.litematica.printer.plus.handler.MineHandler;
import me.aleksilassila.litematica.printer.plus.handler.SpecialBlocksHandler;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.util.math.BlockPos;

import java.util.ArrayList;
import java.util.List;

/** 每客户端会话一个实例，集中持有世界/投影/队列/处理器。 */
public final class WorkContext {
    public final MinecraftClient mc;
    public final WorkQueue queue = new WorkQueue();
    public final List<WorkHandler> handlers = new ArrayList<>();

    public ClientPlayerEntity player;
    public ClientWorld world;
    public WorldSchematic schematic;
    public long tickCounter;

    public WorkContext(MinecraftClient mc) {
        this.mc = mc;
        refresh();

        // 清理顺序与 Fabric 二改/Hana 版一致：排流体 -> 挖掘 -> 破基岩 -> 特殊方块 -> 填充 -> 凭空放置
        handlers.add(new FluidHandler());
        handlers.add(new MineHandler());
        handlers.add(new BedrockHandler());
        handlers.add(new SpecialBlocksHandler());
        handlers.add(new FillHandler());
        handlers.add(new AirPlacementHandler());
    }

    public void refresh() {
        this.player = mc.player;
        this.world = mc.world;
        this.schematic = SchematicWorldHandler.getSchematicWorld();
    }

    /** 玩家能否交互到该坐标（复用基线打印半径）。 */
    public boolean inReach(BlockPos pos) {
        if (player == null || pos == null) return false;
        double r = Configs.PRINTING_RANGE.getDoubleValue();
        double dx = pos.getX() + 0.5 - player.getX();
        double dy = pos.getY() + 0.5 - player.getEyePos().y;
        double dz = pos.getZ() + 0.5 - player.getZ();
        return dx * dx + dy * dy + dz * dz <= r * r;
    }
}
