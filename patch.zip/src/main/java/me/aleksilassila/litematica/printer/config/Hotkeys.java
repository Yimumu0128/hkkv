package me.aleksilassila.litematica.printer.config;

import com.google.common.collect.ImmutableList;
import fi.dy.masa.malilib.config.options.ConfigHotkey;
import fi.dy.masa.malilib.hotkeys.KeybindSettings;
import me.aleksilassila.litematica.printer.PrinterReference;

import java.util.List;

/** 新模式热键，统一出现在 M+C -> Hotkeys 页。 */
public class Hotkeys {
    private static final String HOTKEY_KEY = PrinterReference.MOD_KEY + ".config.hotkeys";

    // 基线原有
    public static final ConfigHotkey PRINT = new ConfigHotkey("print", "V",
            KeybindSettings.PRESS_ALLOWEXTRA_EMPTY, "按住时强制打印");
    public static final ConfigHotkey TOGGLE_PRINTING_MODE = new ConfigHotkey("togglePrintingMode", "CAPS_LOCK",
            KeybindSettings.PRESS_ALLOWEXTRA_EMPTY, "开关原版打印模式");

    // 新增：各工作模式开关（默认不绑定，避免和原版按键冲突，玩家自行在 Hotkeys 页绑定）
    public static final ConfigHotkey TOGGLE_FILL = new ConfigHotkey("toggleFill", "",
            KeybindSettings.PRESS_ALLOWEXTRA_EMPTY, "开关选区填充模式");
    public static final ConfigHotkey TOGGLE_FLUID = new ConfigHotkey("toggleFluid", "",
            KeybindSettings.PRESS_ALLOWEXTRA_EMPTY, "开关流体排空模式");
    public static final ConfigHotkey TOGGLE_MINE = new ConfigHotkey("toggleMine", "",
            KeybindSettings.PRESS_ALLOWEXTRA_EMPTY, "开关挖掘模式（需破坏性总闸）");
    public static final ConfigHotkey TOGGLE_BEDROCK = new ConfigHotkey("toggleBedrock", "",
            KeybindSettings.PRESS_ALLOWEXTRA_EMPTY, "开关破基岩模式");
    public static final ConfigHotkey TOGGLE_AIR = new ConfigHotkey("toggleAir", "",
            KeybindSettings.PRESS_ALLOWEXTRA_EMPTY, "开关凭空放置模式");
    public static final ConfigHotkey EMERGENCY_STOP = new ConfigHotkey("emergencyStop", "",
            KeybindSettings.PRESS_ALLOWEXTRA_EMPTY, "紧急停止：清空任务队列并关闭全部新模式");

    public static List<ConfigHotkey> getHotkeyList() {
        List<ConfigHotkey> list = new java.util.ArrayList<>(fi.dy.masa.litematica.config.Hotkeys.HOTKEY_LIST);
        list.add(PRINT);
        list.add(TOGGLE_PRINTING_MODE);
        list.add(TOGGLE_FILL);
        list.add(TOGGLE_FLUID);
        list.add(TOGGLE_MINE);
        list.add(TOGGLE_BEDROCK);
        list.add(TOGGLE_AIR);
        list.add(EMERGENCY_STOP);
        return ImmutableList.copyOf(list);
    }
}
