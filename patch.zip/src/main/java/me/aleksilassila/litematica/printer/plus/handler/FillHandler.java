package me.aleksilassila.litematica.printer.plus.handler;

import me.aleksilassila.litematica.printer.config.Configs;
import me.aleksilassila.litematica.printer.plus.Chats;
import me.aleksilassila.litematica.printer.plus.CoordinateScanner;
import me.aleksilassila.litematica.printer.plus.InventoryBridge;
import me.aleksilassila.litematica.printer.plus.PlacementHelper;
import me.aleksilassila.litematica.printer.plus.StateMatcher;
import me.aleksilassila.litematica.printer.plus.WorkContext;
import me.aleksilassila.litematica.printer.plus.WorkHandler;
import me.aleksilassila.litematica.printer.plus.WorkQueue;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.util.math.BlockPos;

import java.util.List;

/** 选区填充：用指定方块填满 Forgematica 选区（或玩家范围）。 */
public final class FillHandler implements WorkHandler {
    private final CoordinateScanner scanner = new CoordinateScanner();
    private boolean warnedMissingItem;

    @Override
    public String name() { return "Fill"; }

    @Override
    public boolean isEnabled() { return Configs.ENABLE_FILL.getBooleanValue(); }

    @Override
    public boolean tick(WorkContext ctx) {
        List<BlockPos> coords = scanner.next(ctx, Configs.FILL_USE_SELECTION.getBooleanValue(),
                Math.max(1, Configs.SCAN_BUDGET.getIntegerValue()));
        boolean airOnly = !"ANY".equalsIgnoreCase(Configs.FILL_REPLACE_MODE.getStringValue());

        Item item = Configs.FILL_HAND_HELD.getBooleanValue()
                ? ctx.player.getMainHandStack().getItem()
                : InventoryBridge.parseItem(Configs.FILL_BLOCK.getStringValue());
        if (item == null || item == Items.AIR) {
            if (!warnedMissingItem) {
                Chats.say(ctx, "填充方块 ID 无法解析，请检查 fillBlock 配置");
                warnedMissingItem = true;
            }
            return false;
        }
        warnedMissingItem = false;

        BlockState target = item instanceof BlockItem blockItem
                ? blockItem.getBlock().getDefaultState() : null;

        for (BlockPos pos : coords) {
            if (!ctx.inReach(pos)) continue;
            BlockState cur = ctx.world.getBlockState(pos);

            if (airOnly ? !cur.isAir() : cur.getBlock() == Blocks.BEDROCK) continue;
            if (target != null && StateMatcher.matches(target, cur, true)) continue;

            PlacementHelper.Support support = PlacementHelper.findSupport(ctx.world, pos);
            if (support == null) continue;   // 无支撑的格子交给凭空放置处理器

            ctx.queue.submit(WorkQueue.Task.place(pos, item, support, target));
            return true;
        }
        return false;
    }
}
