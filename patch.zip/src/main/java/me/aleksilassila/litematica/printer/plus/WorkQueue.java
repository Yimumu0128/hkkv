package me.aleksilassila.litematica.printer.plus;

import me.aleksilassila.litematica.printer.config.Configs;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.lang.reflect.Method;
import java.util.ArrayDeque;

/**
 * 串行交互队列：一次只执行一个动作，等服务端方块更新确认后再推进下一个。
 * 这是避免「切物品 / 静默转头 / 放置」三步错位导致放错方块的关键。
 */
public final class WorkQueue {
    private static final Logger LOGGER = LogManager.getLogger("ForgematicaPrinterPlus/Queue");

    public enum Type { PLACE, PLACE_WATER, DRAIN_BUCKET, BREAK, ICE_BREAK, BEDROCK }

    public static final class Task {
        public final Type type;
        public final BlockPos pos;
        public final Item item;
        public final BlockPos clickPos;
        public final Direction side;
        public final BlockState expected;
        public int age;
        public int retries;

        private Task(Type type, BlockPos pos, Item item, BlockPos clickPos, Direction side, BlockState expected) {
            this.type = type;
            this.pos = pos;
            this.item = item;
            this.clickPos = clickPos;
            this.side = side;
            this.expected = expected;
        }

        public static Task place(BlockPos pos, Item item, PlacementHelper.Support support, BlockState expected) {
            return new Task(Type.PLACE, pos, item, support.clickPos, support.side, expected);
        }

        public static Task water(BlockPos pos, PlacementHelper.Support support) {
            return new Task(Type.PLACE_WATER, pos, Items.WATER_BUCKET, support.clickPos, support.side, null);
        }

        public static Task drain(BlockPos pos) {
            return new Task(Type.DRAIN_BUCKET, pos, Items.BUCKET, pos, Direction.UP, null);
        }

        public static Task brk(BlockPos pos, Type type) {
            return new Task(type, pos, null, pos, Direction.UP, null);
        }
    }

    private final ArrayDeque<Task> pending = new ArrayDeque<>();
    private Task current;

    public void submit(Task task) {
        if (task != null && pending.size() < 512) pending.add(task);
    }

    public void submitAll(Task... tasks) {
        for (Task t : tasks) submit(t);
    }

    public boolean isIdle() {
        return current == null && pending.isEmpty();
    }

    public void clear() {
        pending.clear();
        current = null;
    }

    public void tick(WorkContext ctx) {
        if (current == null) {
            current = pending.poll();
            if (current == null) return;
            execute(ctx, current);
            current.age = 0;
            return;
        }

        current.age++;
        if (confirmed(ctx, current)) {
            current = null;
            return;
        }

        // 生存模式挖掘需要持续推进破坏进度，创造模式 attackBlock 一次即可
        if (isBreaking(current.type) && !ctx.player.getAbilities().creativeMode && current.age % 2 == 0) {
            ctx.mc.interactionManager.updateBlockBreakingProgress(current.pos,
                    current.side == null ? Direction.UP : current.side);
        }

        int timeout = Configs.PLACEMENT_TIMEOUT.getIntegerValue();
        if (current.age > timeout) {
            if (current.retries++ < Configs.PLACEMENT_RETRIES.getIntegerValue()) {
                LOGGER.debug("Retry {} at {} (attempt {})", current.type, current.pos, current.retries);
                execute(ctx, current);
                current.age = 0;
            } else {
                LOGGER.warn("Gave up on {} at {} after {} retries (server may have rejected the packet)",
                        current.type, current.pos, current.retries);
                current = null;
            }
        }
    }

    private static boolean isBreaking(Type type) {
        return type == Type.BREAK || type == Type.ICE_BREAK || type == Type.BEDROCK;
    }

    private boolean confirmed(WorkContext ctx, Task task) {
        BlockState now = ctx.world.getBlockState(task.pos);
        switch (task.type) {
            case PLACE:
                return task.expected == null
                        ? !now.isAir()
                        : StateMatcher.matches(task.expected, now, Configs.MATCH_SAME_ITEM.getBooleanValue());
            case PLACE_WATER:
                return !ctx.world.getFluidState(task.pos).isEmpty();
            case DRAIN_BUCKET:
                return ctx.world.getFluidState(task.pos).isEmpty();
            case BREAK, ICE_BREAK:
                return now.isAir();
            case BEDROCK:
                return now.getBlock() != Blocks.BEDROCK;
            default:
                return true;
        }
    }

    private void execute(WorkContext ctx, Task task) {
        if (task.item != null && !InventoryBridge.select(ctx, task.item)) {
            Chats.say(ctx, "背包/快捷栏缺少：" + task.item);
            LOGGER.warn("Missing item {} for {} at {}", task.item, task.type, task.pos);
            task.age = Configs.PLACEMENT_TIMEOUT.getIntegerValue();
            return;
        }

        lookAt(ctx, task.pos);

        if (isBreaking(task.type)) {
            if (task.type == Type.BEDROCK && tryCompanionMod(ctx, task.pos)) return;
            ctx.mc.interactionManager.attackBlock(task.pos,
                    task.side == null ? Direction.UP : task.side);
            return;
        }

        BlockPos click = task.clickPos == null ? task.pos : task.clickPos;
        Direction side = task.side == null ? Direction.UP : task.side;
        BlockHitResult hit = new BlockHitResult(Vec3d.ofCenter(click), side, click, false);
        ctx.mc.interactionManager.interactBlock(ctx.player, Hand.MAIN_HAND, hit);
    }

    /** 静默把视线转向目标格（与基线 PrepareAction 相同的发包方式）。 */
    private void lookAt(WorkContext ctx, BlockPos pos) {
        Vec3d eye = ctx.player.getEyePos();
        Vec3d target = Vec3d.ofCenter(pos);
        double dx = target.x - eye.x;
        double dy = target.y - eye.y;
        double dz = target.z - eye.z;
        float yaw = (float) Math.toDegrees(Math.atan2(-dx, dz));
        float pitch = (float) Math.toDegrees(Math.atan2(-dy, Math.sqrt(dx * dx + dz * dz)));

        PlayerMoveC2SPacket packet = new PlayerMoveC2SPacket.Full(
                ctx.player.getX(), ctx.player.getY(), ctx.player.getZ(),
                yaw, pitch, ctx.player.isOnGround());
        ctx.player.networkHandler.sendPacket(packet);
    }

    /** 配套破基岩 mod：反射调用 public static void breakBlock(BlockPos)。 */
    private boolean tryCompanionMod(WorkContext ctx, BlockPos pos) {
        String className = Configs.BEDROCK_API_CLASS.getStringValue();
        if (className == null || className.isBlank()) return false;
        try {
            Class<?> api = Class.forName(className.trim());
            Method m = api.getMethod("breakBlock", BlockPos.class);
            m.invoke(null, pos);
            return true;
        } catch (Throwable t) {
            LOGGER.debug("Bedrock companion API not usable ({}), falling back to attackBlock", t.toString());
            return false;
        }
    }
}
