package org.thinkingstudio.forgematica.printer;

import me.aleksilassila.litematica.printer.LitematicaMixinMod;
import me.aleksilassila.litematica.printer.PrinterReference;
import me.aleksilassila.litematica.printer.plus.PrinterPlus;
import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.loading.FMLLoader;
import org.thinkingstudio.mafglib.util.ForgeUtils;

@Mod(value = PrinterReference.MOD_ID)
public class ForgematicaPrinter {
    public ForgematicaPrinter() {
        if (FMLLoader.getDist().isClient()) {
            var modContainer = ModLoadingContext.get().getActiveContainer();
            ForgeUtils.getInstance().getClientModIgnoredServerOnly(modContainer);

            // 基线初始化（配置注入、热键回调、Mixin）
            LitematicaMixinMod.onInitialize();

            // 二改：注册 Forge 客户端 tick 事件，驱动新的工作模式
            PrinterPlus.register();
        }
    }
}
